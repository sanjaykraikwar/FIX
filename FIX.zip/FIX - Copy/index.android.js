/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */
 
 
 import './views/BottomNavigationTab';

