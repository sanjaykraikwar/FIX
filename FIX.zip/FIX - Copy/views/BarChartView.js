import React, { Component } from 'react';
import { AppRegistry, StyleSheet, ScrollView , StatusBar, Text, View,Image,Picker,Select,Option } from 'react-native';
import PieChart from 'react-native-pie-chart';
import TaskView from './TaskView';
import PieChartView from './PieChartView';
import { BarChart } from 'react-native-charts'
import styles from '../styles/Stylesheet'
 

 
 const BarChartView = () => {
    return (
     
        <View>
          <BarChart
  dataSets={[
  { 
      fillColor: '#8a2be2', 
      data: [
        { value: 72 },
        
      ],
	   label: 'Company A'
    },
    { 
      fillColor: '#0000ff', 
      data: [
        { value: 99 },
        
      ],
	   label: 'Company B'
    },
	{ 
      fillColor: '#228b22', 
      data: [
        { value: 67 },
        
      ],
	   label: 'Company C'
    },
    
	{ 
      fillColor: '#daa520', 
      data: [
        { value: 76 },
        
      ],
	   label: 'Company D'
    },
	
  ]}
  graduation={10}
  horizontal={false}
  showGrid={true}
  barSpacing={10}
  style={{
    height: 300,
    margin: 15,
  }}/>
         
        </View>
     
    );
  }

export default BarChartView;