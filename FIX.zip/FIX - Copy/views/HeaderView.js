import React, { Component } from 'react';
import {
  AppRegistry,
  StyleSheet,
  Text,
  View,
  Image,ScrollView
} from 'react-native';

import styles from '../styles/Stylesheet';

const HeaderView = () => {
    return (
	 <ScrollView style={{flex: 1}}>
	 <View style={styles.ImageTab}>
		  <Image source={require('../images/logo-white.png')}  />
		  <Text style={styles.title1}>Fixed Income Execution Platform</Text>
		</View>
     
        <View style={styles.container}>
         
          <Text style={styles.title}>Today’s Snapshot</Text>
		 
			
          
		  </View>
      </ScrollView>
    )
  }

	
export default HeaderView;
 
		  