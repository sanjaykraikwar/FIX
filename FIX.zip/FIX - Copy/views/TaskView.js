import React, { Component, PropTypes } from 'react';
import { Image,Text,View, StyleSheet,AppRegistryLinking } from "react-native";
import { Table, TableWraper, Row, Rows, Col, Cols, Cell } from 'react-native-table-component';
 
import styles from '../styles/Stylesheet'



 
const TaskView = () => {
    return (
	<View>
	<View> 
          <Text style={styles.tabletitle} >Tasks</Text>
        <Table>
          <Row data={tableHead} style={styles.head} textStyle={styles.headText} />
          <Rows data={tableData} />
        </Table>
      </View>
	  <View> 
          <Text style={styles.tabletitle} >Live Deals</Text>
        <Table>
          <Row data={tableHead1} style={styles.head} textStyle={styles.headText}/>
          <Rows data={tableData1} />
        </Table>
      </View>
	  <View> 
          <Text style={styles.tabletitle} >Failed</Text>
        <Table>
          <Row data={tableHead2} style={styles.head} textStyle={styles.headText}/>
          <Rows data={tableData2} />
        </Table>
      </View>
	  </View>
    )
	
  }
  
  
 const tableHead =['Project Name', 'TM','Client','Deal Type','Request Type','Request Date','Pricing Date'] ;
    const tableData = [
      ['FIO', 'Whang Yihang','DBS OPS','Project Management','Exception','20 JUL 2017','23 JUL 2017'],
       ['FIO', 'Whang Yihang','DBS OPS','Project Management','Exception','20 JUL 2017','23 JUL 2017'],
	   ['FIO', 'Whang Yihang','DBS OPS','Project Management','Exception','20 JUL 2017','23 JUL 2017'],
    ];
	
	 const tableHead1 = ['Project Name','Client','Int Process','Due Intelligence','Documentation','Regulatory App','Roadshow',];
    const tableData1 = [
      ['FIO', 'Whang Yihang','DBS OPS','Project Management','Exception','20 JUL 2017','23 JUL 2017'],
       ['FIO', 'Whang Yihang','DBS OPS','Project Management','Exception','20 JUL 2017','23 JUL 2017'],
	   ['FIO', 'Whang Yihang','DBS OPS','Project Management','Exception','20 JUL 2017','23 JUL 2017'],
    ];
	
	 const tableHead2 = ['Full Name', 'MX Label','MLC Parent Label','MLC Child Label','FA Label'];
    const tableData2 = [
      ['FIO', 'Whang Yihang','DBS OPS','Project Management','Exception'],
       ['FIO', 'Whang Yihang','DBS OPS','Project Management','Exception'],
	   ['FIO', 'Whang Yihang','DBS OPS','Project Management','Exception'],
    ];
  
export default TaskView;

