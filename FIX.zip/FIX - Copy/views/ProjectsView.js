import React, { Component } from "react";
import { Image,Text,View, StyleSheet,AppRegistry } from "react-native";
import { Table, TableWraper, Row, Rows, Col, Cols, Cell } from 'react-native-table-component';
import styles from '../styles/Stylesheet'
 
 
 
 
const ProjectsView = () => {
    return (
	<View> 
	 <View style={styles.ImageTab}>
		  <Image source={require('../images/logo-white.png')}  />
		  <Text style={styles.title1}>Fixed Income Execution Platform</Text>
		</View>
          <Text style={styles.title}>Valuation Reports</Text>
        <Table>
          <Row data={tableHead} style={styles.head} textStyle={styles.headText}/>
          <Rows data={tableData} style={styles.row} textStyle={styles.text}/>
        </Table>
      </View>
    )
  }

 const tableHead = ['Valuation Date', 'Upload Date/Time'];
    const tableData = [
      ['15 April 2015', '15 April 2015 17:46'],
      ['15 April 2015', '15 April 2015 17:46'],
	  ['15 April 2015', '15 April 2015 17:46'],
    ];
  


export default ProjectsView;

