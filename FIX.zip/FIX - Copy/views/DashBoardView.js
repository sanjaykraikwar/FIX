import React, { Component } from 'react';
import { AppRegistry, StyleSheet, ScrollView , StatusBar, Text, View,Image,Picker,Select,Option } from 'react-native';
import PieChart from 'react-native-pie-chart';
import TaskView from './TaskView';
import PieChartView from './PieChartView';
import BarChartView from './BarChartView';
import { BarChart } from 'react-native-charts'
import styles from '../styles/Stylesheet'
 
const DashBoardView = () => {
    return (
	
	 <ScrollView style={{flex: 1}}>
	 <View style={styles.ImageTab}>
		  <Image source={require('../images/logo-white.png')}  />
		  <Text style={styles.title1}>Fixed Income Execution Platform</Text>
	</View>
     
    <View style={styles.container}>
         
          <Text style={styles.title}>Today’s Snapshot</Text>
			<PieChartView/> 
	 </View> 
		  <BarChartView/>
		  <View>
         <TaskView/>
        </View>
      </ScrollView>
	 
    )
  }


	
export default DashBoardView;
 
