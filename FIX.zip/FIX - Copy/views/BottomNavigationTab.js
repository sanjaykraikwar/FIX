import React from 'react'
import { NavigationComponent } from 'react-native-material-bottom-navigation'
import Icon from 'react-native-vector-icons/MaterialIcons'
import {StackNavigator,DrawerNavigator,TabNavigator} from 'react-navigation';
import {  AppRegistry,Text,Image,Button,View,StyleSheet,Table, TableWraper, Row, Rows, Col, Cols, Cell  } from 'react-native';
import styles from '../styles/Stylesheet'
import  ProjectsView from  './ProjectsView';
import  DashBoardView from  './DashBoardView';
import AdminView from './AdminView';
 

class DashBoard extends React.Component {
	
	 constructor(props) {
     super(props);
   }

  static navigationOptions = {
    tabBarLabel: 'DashBoard',
    tabBarIcon: () => (<Icon size={24} color="white" name="dashboard" />)
  }
  
  
    render() { return (
    <DashBoardView/>
	); }
}
 
class Projects extends React.Component {
  static navigationOptions = {
    tabBarLabel: 'Projects',
    tabBarIcon: () => (<Icon size={24} color="white" name="assignment" />)
  }
  
  render() { return (
      <ProjectsView/>
    ); }
}


class Admin extends React.Component {
  static navigationOptions = {
    tabBarLabel: 'Admin',
    tabBarIcon: () => (<Icon size={24} color="white" name="settings" />)
  }
 
  render() { return (		
       <AdminView/>
    ); }
}
  
const MyApp = TabNavigator({
  DashBoard: { screen: DashBoard },
  Projects: { screen: Projects },
  Admin: { screen: Admin }
  
  
}, {
  tabBarComponent: NavigationComponent,
  tabBarPosition: 'bottom',
  tabBarOptions: {
    bottomNavigationOptions: {
      labelColor: 'white',
      rippleColor: 'red',
      tabs: {
        DashBoard: {
          barBackgroundColor: '#37474F'
        },
        Projects: {
          barBackgroundColor: '#37474F'
        },
		Admin: {
          barBackgroundColor: '#37474F'
        }
       
      }
    }
  }
})



 
 
AppRegistry.registerComponent('FIX', () => MyApp);