import React from 'react';
import {AppRegistry, StyleSheet,Text,View,Button} from 'react-native';
import { NavigationComponent } from 'react-native-material-bottom-navigation'
import { TabNavigator } from "react-navigation";
import  UserView from  './UserView';
import  ClientView from  './ClientView';
import  WorkflowTemplateView from  './WorkflowTemplateView';


const User = () => {
    return (
      <UserView/>
    )
  }


const Client = () => {
    return (   
      <ClientView/>
    )
  }


const WorkflowTemplate = () => {
    return (
       <WorkflowTemplateView/>
    )
  }


const AdminView = TabNavigator({
	User: { screen: User },
  Client: { screen: Client },
  WorkflowTemplate: { screen: WorkflowTemplate },
}, {
  tabBarComponent: NavigationComponent,
  tabBarPosition: 'top',
  tabBarOptions: {
    bottomNavigationOptions: {
      labelColor: 'white',
      rippleColor: 'red',
      tabs: {
        User: {
          barBackgroundColor: '#37474F'
        },
        WorkflowTemplate: {
          barBackgroundColor: '#37474F'
        },
		Client: {
          barBackgroundColor: '#37474F'
        }
       
      }
    }
  }
})

export default AdminView;


