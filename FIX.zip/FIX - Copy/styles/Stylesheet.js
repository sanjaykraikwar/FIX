module.exports = {

    "centerRowAligment":{
        flex: 1,
        backgroundColor:"#a22a5f",
        flexDirection: 'row',
        alignItems:"center"
    },
    "centerColumnAligment":{
        flex: 1,
        justifyContent: 'center',
        flexDirection: 'column',
        alignItems: 'center'
    },
  container: {
    flex: 1,
    alignItems: 'center'
  },
  title: {
    fontSize: 24,
    margin: 10,
	fontWeight: 'bold',
	color: '#37474F'
  },
  tabletitle: {
    fontSize: 18,
    margin: 10,
	fontWeight: 'bold',
	color: '#37474F'
  },
  title1: {
	   color: 'white',
    fontSize: 20,
    margin: 10
  },
  ImageTab:{
	  backgroundColor: '#37474F'
  },
   head: {height: 40, backgroundColor: '#37474F' },
  text: { textAlign: 'center',backgroundColor: "#9E7CE3"},
  row: { height: 30 },
  
  chart: {
    flex: 1
  },
   container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5FCFF',
  },
  welcome: {
    fontSize: 20,
    textAlign: 'center',
    margin: 10,
  },
  instructions: {
    textAlign: 'center',
    color: '#333333',
    marginBottom: 5,
  },
  table: { width: 360, flexDirection: 'row' },
  head: { backgroundColor: '#37474F', height: 60 },
  headText: { color: '#fff', textAlign: 'center' },
  titleText: { marginLeft: 6 },
  list: { height: 70, backgroundColor: '#f0f0f0' },
  listText: { textAlign: 'right', marginRight: 6 }
}

